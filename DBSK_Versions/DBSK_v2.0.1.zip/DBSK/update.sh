#!/bin/sh

git pull
